from django.contrib import admin
from .models import Official

admin.site.register(Official)